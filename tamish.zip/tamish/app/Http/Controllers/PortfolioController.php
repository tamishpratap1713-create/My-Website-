<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PortfolioController extends Controller
{
    /**
     * Get all projects data
     */
    private function getProjects()
    {
        return [
            [
                'id' => 1,
                'title' => 'E-Commerce Website',
                'category' => 'Full Stack',
                'image' => 'https://images.unsplash.com/photo-1556740749-887f6717d7e4?q=80&w=1200',
                'description' => 'A complete e-commerce platform built with Laravel featuring product management, shopping cart, checkout system, and payment integration.',
                'shortDescription' => 'Laravel based premium e-commerce platform.',
                'technologies' => ['Laravel', 'PHP', 'MySQL', 'Tailwind CSS', 'JavaScript'],
                'features' => [
                    'Product Management System',
                    'Shopping Cart & Checkout',
                    'Payment Gateway Integration',
                    'User Authentication',
                    'Admin Dashboard',
                    'Order Management'
                ],
                'demoLink' => '#',
                'codeLink' => '#'
            ],
            [
                'id' => 2,
                'title' => 'Portfolio Website',
                'category' => 'Frontend',
                'image' => 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1200',
                'description' => 'A modern, responsive personal portfolio website showcasing projects, skills, and experience with smooth animations and interactive components.',
                'shortDescription' => 'Modern responsive personal portfolio UI.',
                'technologies' => ['HTML5', 'CSS3', 'JavaScript', 'Tailwind CSS', 'Responsive Design'],
                'features' => [
                    'Responsive Design',
                    'Smooth Animations',
                    'Project Showcase',
                    'Skills Section',
                    'Contact Form',
                    'Social Links'
                ],
                'demoLink' => '#',
                'codeLink' => '#'
            ],
            [
                'id' => 3,
                'title' => 'Admin Dashboard',
                'category' => 'Full Stack',
                'image' => 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1200',
                'description' => 'An advanced admin dashboard with analytics, user management, data visualization, and comprehensive reporting capabilities.',
                'shortDescription' => 'Advanced admin dashboard with analytics UI.',
                'technologies' => ['Laravel', 'PHP', 'MySQL', 'Chart.js', 'Bootstrap'],
                'features' => [
                    'User Management',
                    'Analytics Dashboard',
                    'Data Visualization',
                    'Reports Generation',
                    'Real-time Updates',
                    'Role-based Access'
                ],
                'demoLink' => '#',
                'codeLink' => '#'
            ],
            [
                'id' => 4,
                'title' => 'Blog Platform',
                'category' => 'Full Stack',
                'image' => 'https://images.unsplash.com/photo-1531719965432-13e2b8e1fb5f?q=80&w=1200',
                'description' => 'A full-featured blogging platform with article management, comments, categories, tags, and SEO optimization.',
                'shortDescription' => 'Content management system with blogging features.',
                'technologies' => ['Laravel', 'PHP', 'MySQL', 'Tailwind CSS', 'JavaScript'],
                'features' => [
                    'Article Management',
                    'Comment System',
                    'Categories & Tags',
                    'Search Functionality',
                    'SEO Optimization',
                    'User Profiles'
                ],
                'demoLink' => '#',
                'codeLink' => '#'
            ],
            [
                'id' => 5,
                'title' => 'Task Management App',
                'category' => 'Full Stack',
                'image' => 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=1200',
                'description' => 'A collaborative task management application with real-time updates, team collaboration features, and productivity tracking.',
                'shortDescription' => 'Collaborative task and project management tool.',
                'technologies' => ['Laravel', 'PHP', 'MySQL', 'Vue.js', 'Tailwind CSS'],
                'features' => [
                    'Task Creation & Management',
                    'Team Collaboration',
                    'Real-time Updates',
                    'Progress Tracking',
                    'File Attachments',
                    'Activity Log'
                ],
                'demoLink' => '#',
                'codeLink' => '#'
            ],
            [
                'id' => 6,
                'title' => 'Weather App',
                'category' => 'Frontend',
                'image' => 'https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=1200',
                'description' => 'A beautiful weather application with real-time weather data, location search, and detailed forecasts with a modern UI.',
                'shortDescription' => 'Real-time weather tracking application.',
                'technologies' => ['HTML5', 'CSS3', 'JavaScript', 'Weather API', 'Tailwind CSS'],
                'features' => [
                    'Real-time Weather Data',
                    'Location Search',
                    'Weather Forecast',
                    'Temperature Conversion',
                    'Weather Alerts',
                    'Beautiful UI'
                ],
                'demoLink' => '#',
                'codeLink' => '#'
            ]
        ];
    }

    /**
     * Show home page
     */
    public function index()
    {
        $projects = $this->getProjects();
        return view('portfolio.home', compact('projects'));
    }

    /**
     * Show all projects
     */
    public function projects()
    {
        $projects = $this->getProjects();
        return view('portfolio.projects', compact('projects'));
    }

    /**
     * Show single project detail
     */
    public function projectDetail($id)
    {
        $allProjects = $this->getProjects();
        $project = collect($allProjects)->firstWhere('id', $id);

        if (!$project) {
            abort(404);
        }

        $relatedProjects = collect($allProjects)->where('id', '!=', $id)->take(3);

        return view('portfolio.project-detail', compact('project', 'relatedProjects'));
    }

    /**
     * Show about page
     */
    public function about()
    {
        return view('portfolio.about');
    }

    /**
     * Show contact page
     */
    public function contact()
    {
        return view('portfolio.contact');
    }

    /**
     * Handle contact form submission
     */
    public function submitContact(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'message' => 'required|string|min:10'
        ]);

        // Store in database or send email here
        // For now, just redirect back with success message

        return back()->with('success', 'Thank you! Your message has been sent successfully.');
    }
}
