

<?php $__env->startSection('title', 'Contact Me | Tamish Pratap Singh'); ?>

<?php $__env->startSection('content'); ?>
    <!-- HEADER -->
    <section class="min-h-[40vh] bg-gradient-to-b from-yellow-50 to-white flex items-center pt-32">
        <div class="max-w-7xl mx-auto px-6 w-full">
            <h1 class="text-6xl md:text-7xl font-extrabold text-gradient mb-6">
                Let's Connect
            </h1>
            <p class="text-gray-600 text-xl max-w-3xl">
                Have a project in mind? I'd love to hear from you. Let's discuss how I can help bring your ideas to life.
            </p>
        </div>
    </section>

    <!-- CONTACT CONTENT -->
    <section class="py-32 bg-white">
        <div class="max-w-6xl mx-auto px-6">
            <div class="grid lg:grid-cols-2 gap-16 mb-20">
                <!-- Contact Info -->
                <div>
                    <h2 class="text-4xl font-bold mb-10">Get in Touch</h2>

                    <p class="text-gray-600 leading-9 mb-10 text-lg">
                        I'm available for freelance projects, full-time opportunities, and consultations. Whether you have a question or just want to say hello, feel free to contact me.
                    </p>

                    <div class="space-y-8">
                        <!-- Email -->
                        <div class="glass rounded-[20px] p-8">
                            <div class="flex gap-6 items-start">
                                <div class="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center flex-shrink-0">
                                    <i class="fa-solid fa-envelope text-yellow-600 text-2xl"></i>
                                </div>
                                <div>
                                    <h3 class="text-2xl font-bold mb-2">Email</h3>
                                    <a href="mailto:tamishpratap1713@gmail.com" class="text-yellow-600 hover:text-yellow-700 font-semibold">
                                        tamishpratap1713@gmail.com
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Phone -->
                        <div class="glass rounded-[20px] p-8">
                            <div class="flex gap-6 items-start">
                                <div class="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center flex-shrink-0">
                                    <i class="fa-solid fa-phone text-yellow-600 text-2xl"></i>
                                </div>
                                <div>
                                    <h3 class="text-2xl font-bold mb-2">Phone</h3>
                                    <a href="tel:+918979703005" class="text-yellow-600 hover:text-yellow-700 font-semibold">
                                        +91 8979703005
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Location -->
                        <div class="glass rounded-[20px] p-8">
                            <div class="flex gap-6 items-start">
                                <div class="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center flex-shrink-0">
                                    <i class="fa-solid fa-map-marker-alt text-yellow-600 text-2xl"></i>
                                </div>
                                <div>
                                    <h3 class="text-2xl font-bold mb-2">Location</h3>
                                    <p class="text-gray-600">
                                        Aligarh, Uttar Pradesh<br>
                                        India
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- Social Links -->
                        <div class="pt-8">
                            <h3 class="text-2xl font-bold mb-6">Follow Me</h3>
                            <div class="flex gap-5 text-2xl">
                                <a href="#" class="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center hover:gold-gradient duration-300">
                                    <i class="fa-brands fa-github text-yellow-600 hover:text-black"></i>
                                </a>
                                <a href="#" class="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center hover:gold-gradient duration-300">
                                    <i class="fa-brands fa-linkedin text-yellow-600 hover:text-black"></i>
                                </a>
                                <a href="#" class="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center hover:gold-gradient duration-300">
                                    <i class="fa-brands fa-instagram text-yellow-600 hover:text-black"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Contact Form -->
                <div>
                    <div class="glass rounded-[40px] p-10">
                        <h2 class="text-3xl font-bold mb-8">Send Me a Message</h2>

                        <?php if($errors->any()): ?>
                            <div class="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if(session('success')): ?>
                            <div class="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('contact.submit')); ?>" method="POST" class="space-y-6">
                            <?php echo csrf_field(); ?>

                            <div>
                                <label class="block font-semibold mb-3 text-gray-700">Your Name</label>
                                <input
                                    type="text"
                                    name="name"
                                    value="<?php echo e(old('name')); ?>"
                                    placeholder="Enter your full name"
                                    class="w-full border border-yellow-500/20 bg-white p-4 rounded-2xl outline-none focus:border-yellow-600 focus:ring-2 focus:ring-yellow-200 transition"
                                    required
                                />
                            </div>

                            <div>
                                <label class="block font-semibold mb-3 text-gray-700">Your Email</label>
                                <input
                                    type="email"
                                    name="email"
                                    value="<?php echo e(old('email')); ?>"
                                    placeholder="Enter your email address"
                                    class="w-full border border-yellow-500/20 bg-white p-4 rounded-2xl outline-none focus:border-yellow-600 focus:ring-2 focus:ring-yellow-200 transition"
                                    required
                                />
                            </div>

                            <div>
                                <label class="block font-semibold mb-3 text-gray-700">Your Message</label>
                                <textarea
                                    name="message"
                                    rows="6"
                                    placeholder="Tell me about your project or inquiry..."
                                    class="w-full border border-yellow-500/20 bg-white p-4 rounded-2xl outline-none focus:border-yellow-600 focus:ring-2 focus:ring-yellow-200 transition resize-none"
                                    required
                                ></textarea>
                            </div>

                            <button
                                type="submit"
                                class="w-full gold-gradient px-8 py-4 rounded-full font-semibold shadow-xl hover:scale-105 duration-300"
                            >
                                Send Message
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="py-32 bg-[#fffaf0]">
        <div class="max-w-4xl mx-auto px-6">
            <div class="text-center mb-20">
                <h2 class="text-5xl font-bold text-gradient mb-6">Frequently Asked Questions</h2>
            </div>

            <div class="space-y-6">
                <div class="glass rounded-[20px] p-8">
                    <details class="cursor-pointer">
                        <summary class="text-2xl font-bold text-gray-900 flex items-center justify-between">
                            What is your typical project timeline?
                            <i class="fa-solid fa-chevron-down transition-transform"></i>
                        </summary>
                        <p class="text-gray-600 mt-6">
                            Project timelines vary depending on complexity and scope. A simple website typically takes 2-4 weeks, while complex applications may take 8-12 weeks or more. I'll provide a detailed timeline after discussing your requirements.
                        </p>
                    </details>
                </div>

                <div class="glass rounded-[20px] p-8">
                    <details class="cursor-pointer">
                        <summary class="text-2xl font-bold text-gray-900 flex items-center justify-between">
                            Do you provide maintenance and support?
                            <i class="fa-solid fa-chevron-down transition-transform"></i>
                        </summary>
                        <p class="text-gray-600 mt-6">
                            Yes! I offer post-launch support and maintenance packages. This includes bug fixes, security updates, and performance optimization to ensure your website runs smoothly.
                        </p>
                    </details>
                </div>

                <div class="glass rounded-[20px] p-8">
                    <details class="cursor-pointer">
                        <summary class="text-2xl font-bold text-gray-900 flex items-center justify-between">
                            What is your pricing model?
                            <i class="fa-solid fa-chevron-down transition-transform"></i>
                        </summary>
                        <p class="text-gray-600 mt-6">
                            I offer flexible pricing based on project requirements, including fixed-price projects, hourly rates, and retainer options. Let's discuss what works best for your budget and needs.
                        </p>
                    </details>
                </div>

                <div class="glass rounded-[20px] p-8">
                    <details class="cursor-pointer">
                        <summary class="text-2xl font-bold text-gray-900 flex items-center justify-between">
                            Can you work with my existing team?
                            <i class="fa-solid fa-chevron-down transition-transform"></i>
                        </summary>
                        <p class="text-gray-600 mt-6">
                            Absolutely! I'm experienced in working with teams and clients. I'm flexible with communication styles and can integrate seamlessly with your existing workflow.
                        </p>
                    </details>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<script>
    document.querySelectorAll('details').forEach(detail => {
        detail.addEventListener('toggle', function() {
            const icon = this.querySelector('.fa-chevron-down');
            if (icon) {
                icon.style.transform = this.open ? 'rotate(180deg)' : 'rotate(0deg)';
            }
        });
    });
</script>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\resume\resources\views/portfolio/contact.blade.php ENDPATH**/ ?>