

<?php $__env->startSection('title', $project['title'] . ' | Tamish Pratap Singh'); ?>

<?php $__env->startSection('content'); ?>
    <!-- BREADCRUMB -->
    <section class="pt-32 pb-10 bg-gradient-to-b from-yellow-50 to-white">
        <div class="max-w-7xl mx-auto px-6">
            <nav class="breadcrumb flex items-center gap-3 text-gray-600">
                <a href="<?php echo e(route('home')); ?>" class="hover:text-yellow-600">Home</a>
                <span>/</span>
                <a href="<?php echo e(route('projects')); ?>" class="hover:text-yellow-600">Projects</a>
                <span>/</span>
                <span class="text-yellow-600 font-semibold"><?php echo e($project['title']); ?></span>
            </nav>
        </div>
    </section>

    <!-- PROJECT HERO -->
    <section class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-6">
            <div class="project-hero glass rounded-[40px]">
                <div class="grid md:grid-cols-2 gap-12 items-center">
                    <div>
                        <span class="inline-block px-4 py-2 bg-yellow-100 text-yellow-700 rounded-full text-sm font-semibold mb-6">
                            <?php echo e($project['category']); ?>

                        </span>
                        <h1 class="text-5xl md:text-6xl font-extrabold mb-6">
                            <?php echo e($project['title']); ?>

                        </h1>
                        <p class="text-gray-600 text-lg leading-9 mb-8">
                            <?php echo e($project['description']); ?>

                        </p>
                        <div class="flex flex-wrap gap-4">
                            <a
                                href="<?php echo e($project['demoLink']); ?>"
                                class="gold-gradient px-8 py-4 rounded-full font-semibold hover:scale-105 duration-300"
                            >
                                View Demo
                            </a>
                            <a
                                href="<?php echo e($project['codeLink']); ?>"
                                class="border-2 border-yellow-600 px-8 py-4 rounded-full font-semibold hover:bg-yellow-50 duration-300"
                            >
                                Source Code
                            </a>
                        </div>
                    </div>
                    <div>
                        <img
                            src="<?php echo e($project['image']); ?>"
                            alt="<?php echo e($project['title']); ?>"
                            class="w-full rounded-3xl shadow-lg"
                        />
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- PROJECT DETAILS -->
    <section class="py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-6">
            <!-- Technologies Used -->
            <div class="mb-16">
                <h2 class="text-4xl font-bold mb-10 text-gray-900">
                    Technologies Used
                </h2>
                <div class="tech-stack">
                    <?php $__currentLoopData = $project['technologies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tech-tag">
                            <i class="fa-solid fa-code mr-2 text-yellow-600"></i>
                            <?php echo e($tech); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Features -->
            <div class="mb-16">
                <h2 class="text-4xl font-bold mb-10 text-gray-900">
                    Key Features
                </h2>
                <div class="features-grid">
                    <?php $__currentLoopData = $project['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="feature-card">
                            <h4 class="flex items-center gap-3 mb-3">
                                <i class="fa-solid fa-check-circle text-yellow-600"></i>
                                <?php echo e($feature); ?>

                            </h4>
                            <p>Implemented with modern best practices and user-centric design principles.</p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Project Gallery -->
            <div class="mb-16">
                <h2 class="text-4xl font-bold mb-10 text-gray-900">
                    Project Gallery
                </h2>
                <div class="project-gallery">
                    <div class="gallery-item">
                        <img src="<?php echo e($project['image']); ?>" alt="Screenshot 1" />
                    </div>
                    <div class="gallery-item">
                        <img src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?q=80&w=1000" alt="Screenshot 2" />
                    </div>
                    <div class="gallery-item">
                        <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=1000" alt="Screenshot 3" />
                    </div>
                </div>
            </div>

            <!-- Project Stats -->
            <div class="glass rounded-[30px] p-10">
                <div class="grid md:grid-cols-4 gap-8">
                    <div class="text-center">
                        <div class="text-4xl font-bold text-gradient mb-2">100+</div>
                        <p class="text-gray-600">Code Commits</p>
                    </div>
                    <div class="text-center">
                        <div class="text-4xl font-bold text-gradient mb-2"><?php echo e(count($project['technologies'])); ?></div>
                        <p class="text-gray-600">Technologies</p>
                    </div>
                    <div class="text-center">
                        <div class="text-4xl font-bold text-gradient mb-2"><?php echo e(count($project['features'])); ?></div>
                        <p class="text-gray-600">Key Features</p>
                    </div>
                    <div class="text-center">
                        <div class="text-4xl font-bold text-gradient mb-2">2026</div>
                        <p class="text-gray-600">Completion Year</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- RELATED PROJECTS -->
    <?php if($relatedProjects->count() > 0): ?>
        <section class="py-20 bg-white">
            <div class="max-w-7xl mx-auto px-6">
                <h2 class="text-4xl font-bold mb-12 text-gradient">Related Projects</h2>
                <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
                    <?php $__currentLoopData = $relatedProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="project-card group relative rounded-[35px] overflow-hidden shadow-xl card-hover">
                            <img
                                src="<?php echo e($relatedProject['image']); ?>"
                                class="w-full h-[320px] object-cover group-hover:scale-105 transition-transform duration-500"
                            />

                            <div
                                class="project-overlay absolute inset-0 bg-black/70 flex flex-col justify-center items-center p-8 text-center"
                            >
                                <h3 class="text-2xl font-bold text-white mb-4">
                                    <?php echo e($relatedProject['title']); ?>

                                </h3>

                                <a
                                    href="<?php echo e(route('project.detail', $relatedProject['id'])); ?>"
                                    class="gold-gradient px-6 py-2 rounded-full font-semibold text-black"
                                >
                                    View Project
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <!-- CTA -->
    <section class="py-20 bg-gradient-to-r from-yellow-50 to-yellow-100">
        <div class="max-w-4xl mx-auto px-6 text-center">
            <h2 class="text-4xl font-bold mb-6">Interested in Working Together?</h2>
            <p class="text-gray-700 text-lg mb-8">
                Let's discuss your project requirements and how I can help bring your ideas to life.
            </p>
            <a
                href="<?php echo e(route('contact')); ?>"
                class="inline-block gold-gradient px-10 py-4 rounded-full font-semibold shadow-lg hover:scale-105 duration-300"
            >
                Get in Touch
            </a>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\resume\resources\views\portfolio\project-detail.blade.php ENDPATH**/ ?>