

<?php $__env->startSection('title', 'My Projects | Tamish Pratap Singh'); ?>

<?php $__env->startSection('content'); ?>
    <!-- HEADER -->
    <section class="min-h-[40vh] bg-gradient-to-b from-yellow-50 to-white flex items-center pt-32">
        <div class="max-w-7xl mx-auto px-6 w-full">
            <h1 class="text-6xl md:text-7xl font-extrabold text-gradient mb-6">
                My Projects
            </h1>
            <p class="text-gray-600 text-xl max-w-3xl">
                Explore my collection of modern, responsive web development projects built with premium UI design and advanced coding practices.
            </p>
        </div>
    </section>

    <!-- PROJECTS GRID -->
    <section class="py-32 bg-white">
        <div class="max-w-7xl mx-auto px-6">
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div
                        class="project-card group relative rounded-[35px] overflow-hidden shadow-xl card-hover bg-white"
                    >
                        <img
                            src="<?php echo e($project['image']); ?>"
                            class="w-full h-[420px] object-cover group-hover:scale-105 transition-transform duration-500"
                        />

                        <div
                            class="project-overlay absolute inset-0 bg-black/70 flex flex-col justify-center items-center p-8 text-center"
                        >
                            <span class="inline-block px-4 py-2 bg-yellow-600 text-white rounded-full text-sm font-semibold mb-4">
                                <?php echo e($project['category']); ?>

                            </span>
                            <h3 class="text-3xl font-bold text-white mb-4">
                                <?php echo e($project['title']); ?>

                            </h3>

                            <p class="text-gray-300 mb-6">
                                <?php echo e($project['shortDescription']); ?>

                            </p>

                            <a
                                href="<?php echo e(route('project.detail', $project['id'])); ?>"
                                class="gold-gradient px-7 py-3 rounded-full font-semibold text-black hover:scale-105 duration-300"
                            >
                                View Details
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-full text-center py-20">
                        <p class="text-gray-600 text-xl">No projects found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\resume\resources\views/portfolio/projects.blade.php ENDPATH**/ ?>