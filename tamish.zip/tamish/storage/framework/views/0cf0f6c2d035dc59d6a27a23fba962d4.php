

<?php $__env->startSection('title', 'Tamish Pratap Singh | Full Stack Web Developer'); ?>

<?php $__env->startSection('content'); ?>
    <!-- HERO -->
    <section
        id="home"
        class="min-h-screen hero-bg flex items-center relative overflow-hidden pt-24"
    >
        <!-- Background SVG -->
        <div class="absolute top-0 left-0 w-full opacity-10">
            <svg viewBox="0 0 1440 320">
                <path
                    fill="#D4AF37"
                    d="M0,128L60,138.7C120,149,240,171,360,181.3C480,192,600,192,720,170.7C840,149,960,107,1080,117.3C1200,128,1320,192,1380,224L1440,256V0H0Z"
                ></path>
            </svg>
        </div>

        <!-- Blob -->
        <div
            class="blob absolute top-20 right-20 w-96 h-96 bg-yellow-300/20 rounded-full blur-3xl"
        ></div>

        <div
            class="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center relative z-10"
        >
            <!-- LEFT -->
            <div>
                <p
                    class="uppercase tracking-[5px] text-yellow-700 font-semibold mb-5"
                >
                    Full Stack Web Developer
                </p>

                <h1
                    class="text-6xl md:text-7xl font-extrabold leading-tight mb-6"
                >
                    Hi, I'm
                    <span class="text-gradient"> Tamish </span>
                </h1>

                <div
                    class="typing text-2xl font-semibold text-gray-700 mb-8"
                >
                    Laravel • PHP • HTML • CSS • JavaScript
                </div>

                <p class="text-gray-600 leading-9 text-lg max-w-2xl mb-10">
                    Passionate web developer focused on creating modern,
                    responsive and premium websites using Laravel, PHP,
                    JavaScript and advanced frontend technologies.
                </p>

                <div class="flex flex-wrap gap-5">
                    <a
                        href="<?php echo e(route('projects')); ?>"
                        class="gold-gradient px-8 py-4 rounded-full text-black font-semibold shadow-xl hover:scale-105 duration-300"
                    >
                        View Projects
                    </a>

                    <a
                        href="<?php echo e(route('contact')); ?>"
                        class="border border-yellow-500 px-8 py-4 rounded-full font-semibold hover:bg-yellow-500 hover:text-black duration-300"
                    >
                        Contact Me
                    </a>
                </div>
            </div>

            <!-- RIGHT -->
            <div class="flex justify-center relative">
                <!-- Glow -->
                <div
                    class="absolute w-[400px] h-[400px] bg-yellow-400/20 rounded-full blur-3xl"
                ></div>

                <!-- Card -->
                <div
                    class="relative w-[350px] h-[470px] rounded-[40px] overflow-hidden shadow-[0_30px_80px_rgba(212,175,55,0.25)] border border-yellow-500/20"
                >
                    <!-- SVG TOP -->
                    <svg
                        class="absolute top-0 left-0 w-full"
                        viewBox="0 0 500 150"
                    >
                        <path
                            d="M0 40C120 140 320 0 500 100V0H0V40Z"
                            fill="url(#paint0_linear)"
                        />

                        <defs>
                            <linearGradient
                                id="paint0_linear"
                                x1="0"
                                y1="0"
                                x2="500"
                                y2="150"
                            >
                                <stop stop-color="#FFD700" />
                                <stop offset="1" stop-color="#D4AF37" />
                            </linearGradient>
                        </defs>
                    </svg>

                    <!-- IMAGE -->
                    <img
                        src="<?php echo e(asset('assets/images/profile.jpg')); ?>"
                        alt="Tamish"
                        class="w-full h-full object-cover"
                        onerror="this.style.display='none'"
                    />

                    <!-- Overlay -->
                    <div
                        class="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent"
                    ></div>

                    <!-- Bottom -->
                    <div class="absolute bottom-0 left-0 p-8 text-white">
                        <h2 class="text-4xl font-bold mb-2">Tamish</h2>

                        <p class="text-yellow-300 text-lg">
                            Laravel & PHP Developer
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ABOUT -->
    <section id="about" class="py-32 bg-[#fffaf0]">
        <div class="max-w-7xl mx-auto px-6">
            <div class="text-center mb-20">
                <h2 class="text-5xl font-bold text-gradient mb-6">
                    About Me
                </h2>

                <p
                    class="max-w-3xl mx-auto text-gray-600 text-lg leading-9"
                >
                    I am Tamish Pratap Singh, a passionate and hardworking
                    full stack web developer currently pursuing B.Sc. I
                    continuously improve my skills in Laravel, PHP,
                    JavaScript and modern frontend development.
                </p>
            </div>

            <div class="grid lg:grid-cols-2 gap-10">
                <div class="glass rounded-[30px] p-10 card-hover">
                    <h3 class="text-3xl font-bold mb-8 text-yellow-700">
                        Personal Information
                    </h3>

                    <div class="space-y-6 text-gray-700">
                        <div class="flex gap-4">
                            <i class="fa-solid fa-user text-yellow-600"></i>
                            <p>
                                <strong>Name:</strong> Tamish Pratap Singh
                            </p>
                        </div>

                        <div class="flex gap-4">
                            <i
                                class="fa-solid fa-envelope text-yellow-600"
                            ></i>
                            <p>
                                <strong>Email:</strong>
                                tamishpratap1713@gmail.com
                            </p>
                        </div>

                        <div class="flex gap-4">
                            <i class="fa-solid fa-code text-yellow-600"></i>
                            <p>
                                <strong>Role:</strong> Full Stack Web
                                Developer
                            </p>
                        </div>
                    </div>
                </div>

                <div class="glass rounded-[30px] p-10 card-hover">
                    <h3 class="text-3xl font-bold mb-8 text-yellow-700">
                        My Strengths
                    </h3>

                    <div class="grid gap-5">
                        <div class="flex items-center gap-4">
                            <i
                                class="fa-solid fa-circle-check text-yellow-600"
                            ></i>
                            <p>Hard & Smart Working</p>
                        </div>

                        <div class="flex items-center gap-4">
                            <i
                                class="fa-solid fa-circle-check text-yellow-600"
                            ></i>
                            <p>Honest & Punctual</p>
                        </div>

                        <div class="flex items-center gap-4">
                            <i
                                class="fa-solid fa-circle-check text-yellow-600"
                            ></i>
                            <p>Good Communication Skills</p>
                        </div>

                        <div class="flex items-center gap-4">
                            <i
                                class="fa-solid fa-circle-check text-yellow-600"
                            ></i>
                            <p>Quick Learner</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SKILLS -->
    <section id="skills" class="py-32">
        <div class="max-w-7xl mx-auto px-6">
            <div class="text-center mb-20">
                <h2 class="text-5xl font-bold text-gradient mb-6">
                    My Skills
                </h2>
            </div>

            <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div
                    class="glass rounded-[30px] p-10 text-center card-hover"
                >
                    <i
                        class="fa-brands fa-laravel text-6xl text-yellow-600 mb-6"
                    ></i>

                    <h3 class="text-2xl font-bold mb-3">Laravel</h3>

                    <p class="text-gray-600">
                        Modern Laravel web applications
                    </p>
                </div>

                <div
                    class="glass rounded-[30px] p-10 text-center card-hover"
                >
                    <i
                        class="fa-brands fa-php text-6xl text-yellow-600 mb-6"
                    ></i>

                    <h3 class="text-2xl font-bold mb-3">PHP</h3>

                    <p class="text-gray-600">
                        Backend & dynamic website development
                    </p>
                </div>

                <div
                    class="glass rounded-[30px] p-10 text-center card-hover"
                >
                    <i
                        class="fa-brands fa-js text-6xl text-yellow-600 mb-6"
                    ></i>

                    <h3 class="text-2xl font-bold mb-3">JavaScript</h3>

                    <p class="text-gray-600">
                        Interactive frontend experiences
                    </p>
                </div>

                <div
                    class="glass rounded-[30px] p-10 text-center card-hover"
                >
                    <i
                        class="fa-brands fa-html5 text-6xl text-yellow-600 mb-6"
                    ></i>

                    <h3 class="text-2xl font-bold mb-3">HTML & CSS</h3>

                    <p class="text-gray-600">
                        Responsive premium UI design
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- PROJECTS PREVIEW -->
    <section
        id="projects"
        class="py-32 bg-[#fffaf0] relative overflow-hidden"
    >
        <div class="absolute top-0 left-0 w-full opacity-10">
            <svg viewBox="0 0 1440 320">
                <path
                    fill="#D4AF37"
                    d="M0,224L60,192C120,160,240,96,360,96C480,96,600,160,720,176C840,192,960,160,1080,138.7C1200,117,1320,107,1380,106.7L1440,107V0H0Z"
                ></path>
            </svg>
        </div>

        <div class="max-w-7xl mx-auto px-6 relative z-10">
            <div class="text-center mb-20">
                <h2 class="text-5xl font-bold text-gradient mb-6">
                    My Projects
                </h2>

                <p class="text-gray-600 max-w-3xl mx-auto text-lg">
                    Modern responsive web development projects built with
                    premium UI design and advanced coding.
                </p>
            </div>

            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
                <?php $__currentLoopData = collect($projects)->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- PROJECT -->
                    <div
                        class="project-card relative rounded-[35px] overflow-hidden shadow-xl card-hover"
                    >
                        <img
                            src="<?php echo e($project['image']); ?>"
                            class="w-full h-[420px] object-cover"
                        />

                        <div
                            class="project-overlay absolute inset-0 bg-black/70 flex flex-col justify-center items-center p-8 text-center"
                        >
                            <h3 class="text-3xl font-bold text-white mb-4">
                                <?php echo e($project['title']); ?>

                            </h3>

                            <p class="text-gray-300 mb-6">
                                <?php echo e($project['shortDescription']); ?>

                            </p>

                            <a
                                href="<?php echo e(route('project.detail', $project['id'])); ?>"
                                class="gold-gradient px-7 py-3 rounded-full font-semibold text-black"
                            >
                                View Project
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="text-center mt-12">
                <a
                    href="<?php echo e(route('projects')); ?>"
                    class="inline-block border border-yellow-600 px-10 py-4 rounded-full font-semibold hover:gold-gradient duration-300"
                >
                    View All Projects
                </a>
            </div>
        </div>
    </section>

    <!-- EDUCATION -->
    <section id="education" class="py-32">
        <div class="max-w-5xl mx-auto px-6">
            <div class="text-center mb-20">
                <h2 class="text-5xl font-bold text-gradient mb-6">
                    Education
                </h2>
            </div>

            <div class="space-y-8">
                <div class="glass rounded-[30px] p-10 card-hover">
                    <h3 class="text-3xl font-bold text-yellow-700 mb-4">
                        B.Sc (Pursuing)
                    </h3>

                    <p class="text-gray-600">
                        Raja Mahendra Pratap Singh State University, Aligarh
                    </p>
                </div>

                <div class="glass rounded-[30px] p-10 card-hover">
                    <h3 class="text-3xl font-bold text-yellow-700 mb-4">
                        12th UP Board
                    </h3>

                    <p class="text-gray-600">Passed in 2023 — 60%</p>
                </div>

                <div class="glass rounded-[30px] p-10 card-hover">
                    <h3 class="text-3xl font-bold text-yellow-700 mb-4">
                        10th UP Board
                    </h3>

                    <p class="text-gray-600">Passed in 2021 — 75%</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CONTACT -->
    <section
        id="contact"
        class="py-32 bg-[#fffaf0] relative overflow-hidden"
    >
        <div class="max-w-6xl mx-auto px-6">
            <div class="text-center mb-20">
                <h2 class="text-5xl font-bold text-gradient mb-6">
                    Contact Me
                </h2>
            </div>

            <div class="glass rounded-[40px] p-12">
                <div class="grid lg:grid-cols-2 gap-14">
                    <div>
                        <h3 class="text-4xl font-bold mb-6">
                            Let's Work Together
                        </h3>

                        <p class="text-gray-600 leading-9 mb-10">
                            Feel free to contact me for freelance projects,
                            portfolio websites, Laravel development, and
                            responsive frontend UI design.
                        </p>

                        <div class="space-y-5">
                            <div class="flex gap-4 items-center">
                                <i
                                    class="fa-solid fa-envelope text-yellow-600"
                                ></i>
                                <p>tamishpratap1713@gmail.com</p>
                            </div>

                            <div class="flex gap-4 items-center">
                                <i
                                    class="fa-solid fa-phone text-yellow-600"
                                ></i>
                                <p>+91 8979703005</p>
                            </div>
                        </div>
                    </div>

                    <form action="<?php echo e(route('contact.submit')); ?>" method="POST" class="space-y-6">
                        <?php echo csrf_field(); ?>
                        <input
                            type="text"
                            name="name"
                            placeholder="Your Name"
                            class="w-full border border-yellow-500/20 bg-white p-5 rounded-2xl outline-none focus:border-yellow-600"
                            required
                        />

                        <input
                            type="email"
                            name="email"
                            placeholder="Your Email"
                            class="w-full border border-yellow-500/20 bg-white p-5 rounded-2xl outline-none focus:border-yellow-600"
                            required
                        />

                        <textarea
                            name="message"
                            rows="6"
                            placeholder="Your Message"
                            class="w-full border border-yellow-500/20 bg-white p-5 rounded-2xl outline-none focus:border-yellow-600"
                            required
                        ></textarea>

                        <button
                            type="submit"
                            class="gold-gradient px-8 py-4 rounded-full font-semibold shadow-xl hover:scale-105 duration-300 w-full"
                        >
                            Send Message
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\resume\resources\views\portfolio\home.blade.php ENDPATH**/ ?>