<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>@yield('title', 'Tamish Pratap Singh | Full Stack Web Developer')</title>

    <!-- Tailwind -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Font -->
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet"
    />

    <!-- Icons -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    />

    <!-- Custom CSS -->
    <link rel="stylesheet" href="{{ asset('assets/css/portfolio.css') }}">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: "#D4AF37",
                        secondary: "#f8f4e8",
                        dark: "#111111",
                        lightText: "#666666",
                    },
                },
            },
        };
    </script>
</head>

<body>
    <!-- NAVBAR -->
    <header
        class="fixed top-0 left-0 w-full z-50 bg-white/70 backdrop-blur-xl border-b border-yellow-500/10"
    >
        <div
            class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center"
        >
            <a href="{{ route('home') }}" class="text-3xl font-bold text-gradient">Tamish.</a>

            <nav class="hidden md:flex gap-8 font-medium text-gray-700">
                <a href="{{ route('home') }}#home" class="hover:text-yellow-600 duration-300"
                    >Home</a
                >
                <a href="{{ route('about') }}" class="hover:text-yellow-600 duration-300"
                    >About</a
                >
                <a href="{{ route('home') }}#skills" class="hover:text-yellow-600 duration-300"
                    >Skills</a
                >
                <a
                    href="{{ route('projects') }}"
                    class="hover:text-yellow-600 duration-300"
                    >Projects</a
                >
                <a
                    href="{{ route('home') }}#education"
                    class="hover:text-yellow-600 duration-300"
                    >Education</a
                >
                <a
                    href="{{ route('contact') }}"
                    class="hover:text-yellow-600 duration-300"
                    >Contact</a
                >
            </nav>
        </div>
    </header>

    @yield('content')

    <!-- FOOTER -->
    <footer class="bg-white py-8 border-t border-yellow-500/10">
        <div
            class="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6"
        >
            <h2 class="text-3xl font-bold text-gradient">Tamish.</h2>

            <p class="text-gray-500">
                © 2026 Tamish Pratap Singh | Full Stack Web Developer
            </p>

            <div class="flex gap-5 text-xl">
                <a href="#" class="hover:text-yellow-600 duration-300">
                    <i class="fa-brands fa-github"></i>
                </a>

                <a href="#" class="hover:text-yellow-600 duration-300">
                    <i class="fa-brands fa-linkedin"></i>
                </a>

                <a href="#" class="hover:text-yellow-600 duration-300">
                    <i class="fa-brands fa-instagram"></i>
                </a>
            </div>
        </div>
    </footer>
</body>
</html>
