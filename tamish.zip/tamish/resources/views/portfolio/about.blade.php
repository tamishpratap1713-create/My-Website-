@extends('layouts.app')

@section('title', 'About Me | Tamish Pratap Singh')

@section('content')
    <!-- HEADER -->
    <section class="min-h-[40vh] bg-gradient-to-b from-yellow-50 to-white flex items-center pt-32">
        <div class="max-w-7xl mx-auto px-6 w-full">
            <h1 class="text-6xl md:text-7xl font-extrabold text-gradient mb-6">
                About Me
            </h1>
            <p class="text-gray-600 text-xl max-w-3xl">
                Learn more about my journey, skills, and passion for web development.
            </p>
        </div>
    </section>

    <!-- ABOUT CONTENT -->
    <section class="py-32 bg-white">
        <div class="max-w-7xl mx-auto px-6">
            <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
                <!-- Image -->
                <div class="flex justify-center">
                    <div class="relative w-[350px] h-[470px] rounded-[40px] overflow-hidden shadow-[0_30px_80px_rgba(212,175,55,0.25)] border border-yellow-500/20">
                        <svg
                            class="absolute top-0 left-0 w-full"
                            viewBox="0 0 500 150"
                        >
                            <path
                                d="M0 40C120 140 320 0 500 100V0H0V40Z"
                                fill="url(#paint0_linear)"
                            />

                            <defs>
                                <linearGradient
                                    id="paint0_linear"
                                    x1="0"
                                    y1="0"
                                    x2="500"
                                    y2="150"
                                >
                                    <stop stop-color="#FFD700" />
                                    <stop offset="1" stop-color="#D4AF37" />
                                </linearGradient>
                            </defs>
                        </svg>

                        <img
                            src="{{ asset('assets/images/profile.jpg') }}"
                            alt="Tamish"
                            class="w-full h-full object-cover"
                            onerror="this.style.display='none'"
                        />

                        <div
                            class="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent"
                        ></div>

                        <div class="absolute bottom-0 left-0 p-8 text-white">
                            <h2 class="text-4xl font-bold mb-2">Tamish</h2>
                            <p class="text-yellow-300 text-lg">
                                Full Stack Developer
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Content -->
                <div>
                    <h2 class="text-4xl font-bold mb-6 text-gray-900">Who Am I?</h2>
                    <p class="text-gray-600 text-lg leading-9 mb-6">
                        I am Tamish Pratap Singh, a passionate and hardworking full stack web developer currently pursuing my Bachelor's degree. I have a deep enthusiasm for creating modern, responsive, and user-friendly web applications that solve real-world problems.
                    </p>
                    <p class="text-gray-600 text-lg leading-9 mb-6">
                        With expertise in Laravel, PHP, JavaScript, and modern frontend technologies, I specialize in building complete web solutions from concept to deployment. My approach combines clean code practices, attention to detail, and a strong focus on user experience.
                    </p>
                    <p class="text-gray-600 text-lg leading-9">
                        I'm committed to continuous learning and staying updated with the latest technologies and best practices in web development. Every project is an opportunity to grow and deliver exceptional results.
                    </p>
                </div>
            </div>

            <!-- Stats -->
            <div class="grid md:grid-cols-4 gap-8 my-20">
                <div class="glass rounded-[30px] p-10 text-center card-hover">
                    <div class="text-5xl font-bold text-gradient mb-4">50+</div>
                    <p class="text-gray-600 font-semibold">Projects Completed</p>
                </div>
                <div class="glass rounded-[30px] p-10 text-center card-hover">
                    <div class="text-5xl font-bold text-gradient mb-4">100+</div>
                    <p class="text-gray-600 font-semibold">Happy Clients</p>
                </div>
                <div class="glass rounded-[30px] p-10 text-center card-hover">
                    <div class="text-5xl font-bold text-gradient mb-4">8+</div>
                    <p class="text-gray-600 font-semibold">Technologies</p>
                </div>
                <div class="glass rounded-[30px] p-10 text-center card-hover">
                    <div class="text-5xl font-bold text-gradient mb-4">3+</div>
                    <p class="text-gray-600 font-semibold">Years Experience</p>
                </div>
            </div>
        </div>
    </section>

    <!-- SKILLS & EXPERTISE -->
    <section class="py-32 bg-[#fffaf0]">
        <div class="max-w-7xl mx-auto px-6">
            <div class="text-center mb-20">
                <h2 class="text-5xl font-bold text-gradient mb-6">Skills & Expertise</h2>
                <p class="text-gray-600 text-lg max-w-3xl mx-auto">
                    A comprehensive set of skills developed through continuous learning and practical experience.
                </p>
            </div>

            <div class="grid md:grid-cols-2 gap-10">
                <div class="glass rounded-[30px] p-10">
                    <h3 class="text-3xl font-bold text-yellow-700 mb-8">Backend Development</h3>
                    <div class="space-y-6">
                        <div>
                            <div class="flex justify-between mb-2">
                                <span class="font-semibold">Laravel</span>
                                <span class="text-yellow-600">95%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-gradient-to-r from-yellow-500 to-yellow-600 h-2 rounded-full" style="width: 95%"></div>
                            </div>
                        </div>
                        <div>
                            <div class="flex justify-between mb-2">
                                <span class="font-semibold">PHP</span>
                                <span class="text-yellow-600">90%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-gradient-to-r from-yellow-500 to-yellow-600 h-2 rounded-full" style="width: 90%"></div>
                            </div>
                        </div>
                        <div>
                            <div class="flex justify-between mb-2">
                                <span class="font-semibold">MySQL</span>
                                <span class="text-yellow-600">88%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-gradient-to-r from-yellow-500 to-yellow-600 h-2 rounded-full" style="width: 88%"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="glass rounded-[30px] p-10">
                    <h3 class="text-3xl font-bold text-yellow-700 mb-8">Frontend Development</h3>
                    <div class="space-y-6">
                        <div>
                            <div class="flex justify-between mb-2">
                                <span class="font-semibold">JavaScript</span>
                                <span class="text-yellow-600">92%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-gradient-to-r from-yellow-500 to-yellow-600 h-2 rounded-full" style="width: 92%"></div>
                            </div>
                        </div>
                        <div>
                            <div class="flex justify-between mb-2">
                                <span class="font-semibold">Tailwind CSS</span>
                                <span class="text-yellow-600">93%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-gradient-to-r from-yellow-500 to-yellow-600 h-2 rounded-full" style="width: 93%"></div>
                            </div>
                        </div>
                        <div>
                            <div class="flex justify-between mb-2">
                                <span class="font-semibold">HTML & CSS</span>
                                <span class="text-yellow-600">95%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-gradient-to-r from-yellow-500 to-yellow-600 h-2 rounded-full" style="width: 95%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- PERSONAL INFO -->
    <section class="py-32 bg-white">
        <div class="max-w-7xl mx-auto px-6">
            <div class="text-center mb-20">
                <h2 class="text-5xl font-bold text-gradient mb-6">Personal Information</h2>
            </div>

            <div class="grid md:grid-cols-2 gap-10">
                <div class="glass rounded-[30px] p-10 card-hover">
                    <h3 class="text-3xl font-bold mb-8 text-yellow-700">Contact Details</h3>

                    <div class="space-y-6 text-gray-700">
                        <div class="flex gap-4">
                            <i class="fa-solid fa-user text-yellow-600 text-xl"></i>
                            <div>
                                <p class="font-semibold">Full Name</p>
                                <p>Tamish Pratap Singh</p>
                            </div>
                        </div>

                        <div class="flex gap-4">
                            <i class="fa-solid fa-envelope text-yellow-600 text-xl"></i>
                            <div>
                                <p class="font-semibold">Email</p>
                                <p><a href="mailto:tamishpratap1713@gmail.com" class="hover:text-yellow-600">tamishpratap1713@gmail.com</a></p>
                            </div>
                        </div>

                        <div class="flex gap-4">
                            <i class="fa-solid fa-phone text-yellow-600 text-xl"></i>
                            <div>
                                <p class="font-semibold">Phone</p>
                                <p><a href="tel:+918979703005" class="hover:text-yellow-600">+91 8979703005</a></p>
                            </div>
                        </div>

                        <div class="flex gap-4">
                            <i class="fa-solid fa-map-marker-alt text-yellow-600 text-xl"></i>
                            <div>
                                <p class="font-semibold">Location</p>
                                <p>Aligarh, Uttar Pradesh, India</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="glass rounded-[30px] p-10 card-hover">
                    <h3 class="text-3xl font-bold mb-8 text-yellow-700">My Strengths</h3>

                    <div class="grid gap-5">
                        <div class="flex items-center gap-4">
                            <i
                                class="fa-solid fa-circle-check text-yellow-600 text-2xl"
                            ></i>
                            <div>
                                <p class="font-semibold">Hard & Smart Working</p>
                                <p class="text-sm text-gray-500">Dedicated and efficient approach to problem-solving</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-4">
                            <i
                                class="fa-solid fa-circle-check text-yellow-600 text-2xl"
                            ></i>
                            <div>
                                <p class="font-semibold">Honest & Punctual</p>
                                <p class="text-sm text-gray-500">Reliable and professional in all commitments</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-4">
                            <i
                                class="fa-solid fa-circle-check text-yellow-600 text-2xl"
                            ></i>
                            <div>
                                <p class="font-semibold">Good Communication</p>
                                <p class="text-sm text-gray-500">Clear and effective interaction with clients</p>
                            </div>
                        </div>

                        <div class="flex items-center gap-4">
                            <i
                                class="fa-solid fa-circle-check text-yellow-600 text-2xl"
                            ></i>
                            <div>
                                <p class="font-semibold">Quick Learner</p>
                                <p class="text-sm text-gray-500">Adaptable to new technologies and frameworks</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
